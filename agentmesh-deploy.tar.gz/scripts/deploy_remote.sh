#!/bin/bash
# Usage: ./scripts/deploy_remote.sh [USER] [HOST] [SSH_KEY_PATH]

set -e

USER=$1
HOST=$2
KEY=$3

if [ -z "$USER" ] || [ -z "$HOST" ]; then
  echo "Usage: ./scripts/deploy_remote.sh [USER] [HOST] [SSH_KEY_PATH]"
  exit 1
fi

SSH_OPTS="-o StrictHostKeyChecking=no"
if [ ! -z "$KEY" ]; then
  SSH_OPTS="$SSH_OPTS -i $KEY"
fi

echo "Deploying to $USER@$HOST..."

# 1. Sync files
echo "Syncing files..."
rsync -avz -e "ssh $SSH_OPTS" \
  --exclude 'venv' \
  --exclude '__pycache__' \
  --exclude '.git' \
  --exclude 'node_modules' \
  --exclude '.next' \
  --exclude 'scripts/deploy_remote.sh' \
  ./ $USER@$HOST:~/agentmesh/

# 2. Run setup and deploy on remote
echo "Running remote deployment..."
ssh $SSH_OPTS $USER@$HOST << 'EOF'
  set -e
  
  # Install Docker if not exists (Ubuntu/Debian)
  if ! command -v docker &> /dev/null; then
    echo "Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    echo "Docker installed. Please re-login or run 'newgrp docker' to use docker without sudo."
  fi

  # Install Docker Compose if not exists
  if ! docker compose version &> /dev/null; then
     echo "Installing Docker Compose Plugin..."
     sudo apt-get update && sudo apt-get install -y docker-compose-plugin || true
  fi

  cd ~/agentmesh

  # Create .env if not exists
  if [ ! -f .env ]; then
    echo "Creating .env..."
    echo "AGENTMESH_AUTH_SECRET=$(openssl rand -hex 32)" > .env
    echo "AGENTMESH_API_KEY=$(openssl rand -hex 32)" >> .env
    echo "POSTGRES_USER=agentmesh" >> .env
    echo "POSTGRES_PASSWORD=$(openssl rand -hex 16)" >> .env
    echo "POSTGRES_DB=agentmesh" >> .env
    echo "NEXT_PUBLIC_API_URL=http://localhost/api" >> .env
  fi

  echo "Building and starting services..."
  sudo docker compose -f docker-compose.prod.yml up -d --build
  
  echo "Deployment complete! Services are running."
  sudo docker compose -f docker-compose.prod.yml ps
EOF
