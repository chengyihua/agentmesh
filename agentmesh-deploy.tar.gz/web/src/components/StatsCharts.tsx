"use client";

import { NetworkGraph } from "./NetworkGraph";

export function StatsCharts() {
    return (
        <div className="w-full h-full">
            <NetworkGraph />
        </div>
    );
}
